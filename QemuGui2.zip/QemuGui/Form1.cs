using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QemuLauncher
{
    public class PhysicalDriveInfo
    {
        public int Number { get; set; }
        public double SizeGB { get; set; }
        public string Status { get; set; }

        public PhysicalDriveInfo(int number, double sizeGB, string status)
        {
            Number = number;
            SizeGB = sizeGB;
            Status = status;
        }
    }

    public class AppSettings
    {
        public string QemuPath { get; set; } = @"C:\Program Files\qemu\qemu-system-x86_64.exe";
        public string ISO { get; set; } = "";
        public string DiskType { get; set; } = "HDD Image";
        public string PhysicalDriveDisplay { get; set; } = "";
        public string HDDImage { get; set; } = "";
        public string CPU { get; set; } = "qemu64";
        public string Cores { get; set; } = "2";
        public string RAM { get; set; } = "1024";
        public string Chipset { get; set; } = "q35";
        public bool Audio { get; set; } = false;
        public string Video { get; set; } = "std";
        public string Network { get; set; } = "User (Slirp)";
        public string NetworkModel { get; set; } = "e1000";
        public string MAC { get; set; } = "52:54:00:12:34:56";
        public decimal WindowWidth { get; set; } = 0;
        public decimal WindowHeight { get; set; } = 0;
        public string AudioBackend { get; set; } = "dsound";
        public int AcceleratorIndex { get; set; } = 0;
        public string ExtraArgs { get; set; } = "";
        public int BootOrderIndex { get; set; } = 0;
        public int HddControllerIndex { get; set; } = 0;
        public string KeyboardType { get; set; } = "PS/2";
        public string MouseType { get; set; } = "USB Tablet";
        public string UsbController { get; set; } = "Auto";
    }

    public partial class Form1 : Form
    {
        private const string SettingsFilePath = "qemu-launcher-settings.json";
        private const string DefaultQemuPath = @"C:\Program Files\qemu\qemu-system-x86_64.exe";

        // Таймаут запуска diskpart-скриптов (мс)
        private const int DiskpartTimeoutMs = 10000;

        private TextBox txtQemuPath;
        private Button btnBrowseQemu;
        private Button btnReloadQemu;
        private TextBox txtISO;
        private Button btnBrowseISO;
        private ComboBox cmbDiskType;
        private Panel pnlPhysicalDrive;
        private ComboBox cmbPhysicalDrive;
        private Button btnRefreshDrives;
        private Button btnSetOffline;
        private Panel pnlHddImage;
        private TextBox txtHDD;
        private Button btnBrowseHDD;
        private Button btnCreateHDD;
        private ComboBox cmbCPU;
        private ComboBox cmbCores;
        private ComboBox cmbRAM;
        private ComboBox cmbAccelerator;
        private ComboBox cmbChipset;
        private CheckBox chkAudio;
        private ComboBox cmbAudioBackend;
        private ComboBox cmbVideo;
        private ComboBox cmbNetwork;
        private TextBox txtMAC;
        private Button btnGenerateMAC;
        private NumericUpDown numWidth;
        private NumericUpDown numHeight;
        private Button btnStart;
        private Button btnSave;
        private Button btnLoad;
        private Label lblStatus;
        private TextBox txtExtraArgs;
        private ComboBox cmbBootOrder;
        private ComboBox cmbHddController;
        private ComboBox cmbNetworkModel;
        private ComboBox cmbKeyboard;
        private ComboBox cmbMouse;
        private ComboBox cmbUsbController;

        // FIX: ToolTip хранится как поле, иначе GC его соберёт и тултипы пропадут
        private ToolTip _toolTip;

        private List<PhysicalDriveInfo> _allDrives = new List<PhysicalDriveInfo>();
        private readonly CancellationTokenSource _cancellationTokenSource;

        private string _pendingCpu;
        private string _pendingChipset;
        private string _pendingVideo;
        private string _pendingAudioBackend;
        private string _pendingNetworkModel;
        private string _pendingPhysicalDriveDisplay;

        // Карты VGA, поддерживающие кастомное разрешение окна
        private static readonly HashSet<string> ResizableVgaCards = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "virtio-vga", "qxl", "vmvga", "virtio-gpu", "vmware"
        };

        public Form1() : this(new CancellationTokenSource()) { }

        public Form1(CancellationTokenSource cancellationTokenSource)
        {
            _cancellationTokenSource = cancellationTokenSource ?? new CancellationTokenSource();
            InitializeComponent();
            this.AutoScaleMode = AutoScaleMode.Font;
            LoadSettingsOnStart();
            this.FormClosing += Form1_FormClosing;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _cancellationTokenSource?.Cancel();
            BtnSave_Click(sender, EventArgs.Empty);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            this.Text = "QEMU Launcher";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Size = new Size(650, 780);

            Label lblQemuPath = new Label { Text = "QEMU path:", Location = new Point(15, 20), Size = new Size(100, 23) };
            txtQemuPath = new TextBox { Location = new Point(120, 18), Size = new Size(320, 23) };
            btnBrowseQemu = new Button { Text = "Browse...", Location = new Point(450, 16), Size = new Size(80, 27) };
            btnBrowseQemu.Click += BtnBrowseQemu_Click;
            btnReloadQemu = new Button { Text = "Reload", Location = new Point(540, 16), Size = new Size(60, 27) };
            btnReloadQemu.Click += (s, e) => ReloadQemuConfig();

            Label lblISO = new Label { Text = "ISO Image:", Location = new Point(15, 55), Size = new Size(100, 23) };
            txtISO = new TextBox { Location = new Point(120, 53), Size = new Size(320, 23) };
            btnBrowseISO = new Button { Text = "Browse...", Location = new Point(450, 51), Size = new Size(80, 27) };
            btnBrowseISO.Click += BtnBrowseISO_Click;

            Label lblDiskType = new Label { Text = "Disk Type:", Location = new Point(15, 90), Size = new Size(100, 23) };
            cmbDiskType = new ComboBox { Location = new Point(120, 88), Size = new Size(150, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbDiskType.Items.AddRange(new object[] { "PhysicalDrive", "HDD Image" });
            cmbDiskType.SelectedIndex = 1;
            cmbDiskType.SelectedIndexChanged += CmbDiskType_SelectedIndexChanged;

            pnlPhysicalDrive = new Panel { Location = new Point(15, 120), Size = new Size(600, 70), Visible = false };
            Label lblPhys = new Label { Text = "PhysicalDrive:", Location = new Point(0, 5), Size = new Size(100, 23) };
            cmbPhysicalDrive = new ComboBox { Location = new Point(105, 3), Size = new Size(350, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            btnRefreshDrives = new Button { Text = "Refresh", Location = new Point(465, 1), Size = new Size(70, 27) };
            btnRefreshDrives.Click += BtnRefreshDrives_Click;
            btnSetOffline = new Button { Text = "Set Offline", Location = new Point(105, 35), Size = new Size(90, 27) };
            btnSetOffline.Click += BtnSetOffline_Click;
            pnlPhysicalDrive.Controls.AddRange(new Control[] { lblPhys, cmbPhysicalDrive, btnRefreshDrives, btnSetOffline });

            pnlHddImage = new Panel { Location = new Point(15, 120), Size = new Size(600, 70), Visible = true };
            Label lblHdd = new Label { Text = "HDD Image:", Location = new Point(0, 5), Size = new Size(100, 23) };
            txtHDD = new TextBox { Location = new Point(105, 3), Size = new Size(250, 23) };
            btnBrowseHDD = new Button { Text = "Browse...", Location = new Point(365, 1), Size = new Size(80, 27) };
            btnBrowseHDD.Click += BtnBrowseHDD_Click;
            btnCreateHDD = new Button { Text = "Create...", Location = new Point(105, 35), Size = new Size(80, 27) };
            btnCreateHDD.Click += BtnCreateHDD_Click;
            pnlHddImage.Controls.AddRange(new Control[] { lblHdd, txtHDD, btnBrowseHDD, btnCreateHDD });

            Label lblHddController = new Label { Text = "HDD Controller:", Location = new Point(15, 200), Size = new Size(100, 23) };
            cmbHddController = new ComboBox { Location = new Point(120, 198), Size = new Size(100, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbHddController.Items.AddRange(new object[] { "IDE", "AHCI", "SCSI" });
            cmbHddController.SelectedIndex = 0;

            Label lblBootOrder = new Label { Text = "Boot order:", Location = new Point(250, 200), Size = new Size(100, 23) };
            cmbBootOrder = new ComboBox { Location = new Point(350, 198), Size = new Size(150, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbBootOrder.Items.AddRange(new object[] { "CD-ROM first", "HDD first", "Only CD-ROM", "Only HDD", "Network (PXE) first" });
            cmbBootOrder.SelectedIndex = 0;

            Label lblCPU = new Label { Text = "CPU model:", Location = new Point(15, 240), Size = new Size(100, 23) };
            cmbCPU = new ComboBox { Location = new Point(120, 238), Size = new Size(180, 23), DropDownStyle = ComboBoxStyle.DropDownList, SelectedIndex = -1 };

            Label lblCores = new Label { Text = "Cores:", Location = new Point(310, 240), Size = new Size(50, 23) };
            cmbCores = new ComboBox { Location = new Point(360, 238), Size = new Size(60, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbCores.Items.AddRange(new object[] { "1", "2", "4" });
            cmbCores.SelectedIndex = 1;

            Label lblRAM = new Label { Text = "RAM (MB):", Location = new Point(15, 275), Size = new Size(100, 23) };
            cmbRAM = new ComboBox { Location = new Point(120, 273), Size = new Size(130, 23), DropDownStyle = ComboBoxStyle.DropDown };
            cmbRAM.Items.AddRange(new object[] { "256", "512", "1024", "2048", "4096", "6144", "8192", "16384" });
            cmbRAM.SelectedIndex = 2;
            cmbRAM.Text = "1024";

            Label lblAccel = new Label { Text = "Acceleration:", Location = new Point(310, 275), Size = new Size(100, 23) };
            cmbAccelerator = new ComboBox { Location = new Point(410, 273), Size = new Size(150, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbAccelerator.Items.AddRange(new object[] { "TCG (software)", "Hyper-V (whpx)", "HAXM (hax)", "KVM (Linux)" });
            cmbAccelerator.SelectedIndex = 0;

            Label lblChipset = new Label { Text = "Chipset:", Location = new Point(15, 310), Size = new Size(100, 23) };
            cmbChipset = new ComboBox { Location = new Point(120, 308), Size = new Size(180, 23), DropDownStyle = ComboBoxStyle.DropDownList, SelectedIndex = -1 };

            chkAudio = new CheckBox { Text = "Add Audio", Location = new Point(310, 308), Size = new Size(100, 24) };
            cmbAudioBackend = new ComboBox { Location = new Point(410, 308), Size = new Size(120, 23), DropDownStyle = ComboBoxStyle.DropDownList, Enabled = false, SelectedIndex = -1 };
            chkAudio.CheckedChanged += (s, e) => cmbAudioBackend.Enabled = chkAudio.Checked;

            Label lblVideo = new Label { Text = "Video card (-vga):", Location = new Point(15, 345), Size = new Size(100, 23) };
            cmbVideo = new ComboBox { Location = new Point(120, 343), Size = new Size(180, 23), DropDownStyle = ComboBoxStyle.DropDownList, SelectedIndex = -1 };

            Label lblNetwork = new Label { Text = "Network:", Location = new Point(15, 380), Size = new Size(100, 23) };
            cmbNetwork = new ComboBox { Location = new Point(120, 378), Size = new Size(150, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbNetwork.Items.AddRange(new object[] { "User (Slirp)", "Tap (Bridge)", "None" });
            cmbNetwork.SelectedIndex = 0;

            Label lblMAC = new Label { Text = "MAC Address:", Location = new Point(15, 415), Size = new Size(100, 23) };
            txtMAC = new TextBox { Location = new Point(120, 413), Size = new Size(150, 23), Text = "52:54:00:12:34:56" };
            btnGenerateMAC = new Button { Text = "Generate", Location = new Point(280, 411), Size = new Size(80, 27) };
            btnGenerateMAC.Click += BtnGenerateMAC_Click;

            Label lblNetworkModel = new Label { Text = "NIC model:", Location = new Point(15, 450), Size = new Size(100, 23) };
            cmbNetworkModel = new ComboBox { Location = new Point(120, 448), Size = new Size(150, 23), DropDownStyle = ComboBoxStyle.DropDownList };

            Label lblKeyboard = new Label { Text = "Keyboard:", Location = new Point(15, 485), Size = new Size(100, 23) };
            cmbKeyboard = new ComboBox { Location = new Point(120, 483), Size = new Size(120, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbKeyboard.Items.AddRange(new object[] { "PS/2", "USB" });
            cmbKeyboard.SelectedIndex = 0;

            Label lblMouse = new Label { Text = "Mouse:", Location = new Point(270, 485), Size = new Size(50, 23) };
            cmbMouse = new ComboBox { Location = new Point(320, 483), Size = new Size(130, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbMouse.Items.AddRange(new object[] { "PS/2", "USB Mouse", "USB Tablet" });
            cmbMouse.SelectedIndex = 2;

            Label lblUsbController = new Label { Text = "USB Ctrl:", Location = new Point(15, 520), Size = new Size(100, 23) };
            cmbUsbController = new ComboBox { Location = new Point(120, 518), Size = new Size(130, 23), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbUsbController.Items.AddRange(new object[] { "Auto", "XHCI (USB 3.0)", "EHCI (USB 2.0)", "UHCI (USB 1.1)" });
            cmbUsbController.SelectedIndex = 0;

            Label lblRes = new Label { Text = "Max window size (W x H):", Location = new Point(15, 555), Size = new Size(150, 23) };
            numWidth = new NumericUpDown { Location = new Point(170, 553), Size = new Size(60, 23), Minimum = 0, Maximum = 4096, Value = 0 };
            Label lblX = new Label { Text = "x", Location = new Point(235, 555), Size = new Size(15, 23) };
            numHeight = new NumericUpDown { Location = new Point(255, 553), Size = new Size(60, 23), Minimum = 0, Maximum = 4096, Value = 0 };

            // FIX: Font создаётся явно и добавляется в компонент формы для последующего диспоза
            var autoLabelFont = new Font("Segoe UI", 8);
            Label lblAuto = new Label { Text = "(0 = auto)", Location = new Point(325, 555), Size = new Size(80, 23), ForeColor = Color.Gray, Font = autoLabelFont };

            Label lblExtraArgs = new Label { Text = "Extra args:", Location = new Point(15, 590), Size = new Size(100, 23) };
            var extraArgsFont = new Font("Consolas", 9);
            txtExtraArgs = new TextBox { Location = new Point(120, 588), Size = new Size(420, 23), Font = extraArgsFont };

            // FIX: ToolTip хранится в поле _toolTip, чтобы GC не собрал объект
            _toolTip = new ToolTip();
            _toolTip.SetToolTip(txtExtraArgs, "Additional QEMU parameters (e.g. -display sdl -device usb-host...)");

            btnStart = new Button { Text = "Start QEMU", Location = new Point(120, 630), Size = new Size(120, 35) };
            btnStart.Click += BtnStart_Click;
            btnSave = new Button { Text = "Save Settings", Location = new Point(260, 630), Size = new Size(100, 35) };
            btnSave.Click += BtnSave_Click;
            btnLoad = new Button { Text = "Load Settings", Location = new Point(380, 630), Size = new Size(100, 35) };
            btnLoad.Click += BtnLoad_Click;

            lblStatus = new Label
            {
                Text = "Ready. PhysicalDrive requires OFFLINE state and admin rights.",
                Location = new Point(15, 680),
                Size = new Size(600, 30),
                ForeColor = Color.Gray
            };

            this.Controls.AddRange(new Control[] {
                lblQemuPath, txtQemuPath, btnBrowseQemu, btnReloadQemu,
                lblISO, txtISO, btnBrowseISO,
                lblDiskType, cmbDiskType,
                pnlPhysicalDrive, pnlHddImage,
                lblHddController, cmbHddController, lblBootOrder, cmbBootOrder,
                lblCPU, cmbCPU, lblCores, cmbCores, lblRAM, cmbRAM,
                lblAccel, cmbAccelerator,
                lblChipset, cmbChipset, chkAudio, cmbAudioBackend,
                lblVideo, cmbVideo,
                lblNetwork, cmbNetwork, lblMAC, txtMAC, btnGenerateMAC,
                lblNetworkModel, cmbNetworkModel,
                lblKeyboard, cmbKeyboard, lblMouse, cmbMouse,
                lblUsbController, cmbUsbController,
                lblRes, numWidth, lblX, numHeight, lblAuto,
                lblExtraArgs, txtExtraArgs,
                btnStart, btnSave, btnLoad,
                lblStatus
            });

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // ----------------------------------------------------------------------
        // QEMU configuration
        // ----------------------------------------------------------------------
        private void ReloadQemuConfig()
        {
            if (string.IsNullOrWhiteSpace(txtQemuPath.Text) || !File.Exists(txtQemuPath.Text))
            {
                lblStatus.Text = "QEMU executable not found. Using fallback lists.";
                SetFallbackOptions();
                ApplyComboBoxSelections();
                return;
            }

            var config = QemuConfig.LoadOrCreate(txtQemuPath.Text);
            if (config == null)
            {
                lblStatus.Text = "Failed to load QEMU configuration.";
                SetFallbackOptions();
                ApplyComboBoxSelections();
                return;
            }

            if (config.CPUs != null && config.CPUs.Count > 0)
            {
                cmbCPU.Items.Clear();
                cmbCPU.Items.AddRange(config.CPUs.Cast<object>().ToArray());
            }

            if (config.Machines != null && config.Machines.Count > 0)
            {
                cmbChipset.Items.Clear();
                cmbChipset.Items.AddRange(config.Machines.Cast<object>().ToArray());
            }

            if (config.VideoCards != null && config.VideoCards.Count > 0)
            {
                cmbVideo.Items.Clear();
                cmbVideo.Items.AddRange(config.VideoCards.Cast<object>().ToArray());
            }
            else
            {
                cmbVideo.Items.Clear();
                cmbVideo.Items.AddRange(new object[] { "std", "cirrus", "vmware", "qxl", "virtio" });
            }

            if (config.AudioDevices != null && config.AudioDevices.Count > 0)
            {
                cmbAudioBackend.Items.Clear();
                cmbAudioBackend.Items.AddRange(config.AudioDevices.Cast<object>().ToArray());
                chkAudio.Text = $"Add Audio ({string.Join(",", config.AudioDevices.Take(3))})";
            }
            else
            {
                cmbAudioBackend.Items.Clear();
                cmbAudioBackend.Items.AddRange(new object[] { "dsound", "none" });
                chkAudio.Text = "Add Audio";
            }

            if (config.NetworkDevices != null && config.NetworkDevices.Count > 0)
            {
                cmbNetworkModel.Items.Clear();
                cmbNetworkModel.Items.AddRange(config.NetworkDevices.Cast<object>().ToArray());
            }

            ApplyComboBoxSelections();
            lblStatus.Text = "QEMU configuration loaded.";
        }

        private void ApplyComboBoxSelections()
        {
            SetComboBoxSelection(cmbCPU, _pendingCpu, "qemu64");
            SetComboBoxSelection(cmbChipset, _pendingChipset, "q35");
            SetComboBoxSelection(cmbVideo, _pendingVideo, "std");
            SetComboBoxSelection(cmbAudioBackend, _pendingAudioBackend, "dsound");
            SetComboBoxSelection(cmbNetworkModel, _pendingNetworkModel, "e1000");
        }

        private static void SetComboBoxSelection(ComboBox cmb, string value, string defaultValue)
        {
            if (!string.IsNullOrEmpty(value))
            {
                int idx = cmb.FindStringExact(value);
                if (idx >= 0)
                {
                    cmb.SelectedIndex = idx;
                    return;
                }
            }

            int defIdx = cmb.FindStringExact(defaultValue);
            if (defIdx >= 0)
                cmb.SelectedIndex = defIdx;
            else if (cmb.Items.Count > 0)
                cmb.SelectedIndex = 0;
        }

        private static void SelectComboByValue(ComboBox cmb, string value)
        {
            if (string.IsNullOrEmpty(value)) return;
            int idx = cmb.FindStringExact(value);
            if (idx >= 0) cmb.SelectedIndex = idx;
        }

        private void SetFallbackOptions()
        {
            cmbCPU.Items.Clear();
            cmbCPU.Items.AddRange(new object[] { "qemu64", "host", "core2duo", "penryn" });

            cmbChipset.Items.Clear();
            cmbChipset.Items.AddRange(new object[] { "pc", "q35" });

            cmbVideo.Items.Clear();
            cmbVideo.Items.AddRange(new object[] { "std", "cirrus", "vmware", "qxl", "virtio" });

            cmbAudioBackend.Items.Clear();
            cmbAudioBackend.Items.AddRange(new object[] { "dsound", "none" });

            cmbNetworkModel.Items.Clear();
            cmbNetworkModel.Items.AddRange(new object[] { "e1000", "rtl8139", "virtio-net-pci" });

            chkAudio.Text = "Add Audio";
        }

        // ----------------------------------------------------------------------
        // Helpers
        // ----------------------------------------------------------------------
        private static bool IsRunAsAdmin()
        {
            var wi = System.Security.Principal.WindowsIdentity.GetCurrent();
            var wp = new System.Security.Principal.WindowsPrincipal(wi);
            return wp.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
        }

        private void RestartAsAdmin()
        {
            var startInfo = new ProcessStartInfo
            {
                FileName = Application.ExecutablePath,
                UseShellExecute = true,
                Verb = "runas"
            };
            try
            {
                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to restart as administrator: {ex.Message}", "Error");
                return;
            }
            Application.Exit();
        }

        private static string AnalyzeQemuError(string errorText)
        {
            if (string.IsNullOrWhiteSpace(errorText))
                return "QEMU exited without visible error message.\nCheck parameters and permissions.";

            string lower = errorText.ToLowerInvariant();

            if (lower.Contains("whpx") && lower.Contains("not available"))
                return "Hyper-V (WHPX) is not available.\nMake sure:\n- Virtualization is enabled in BIOS\n- Hyper-V is enabled (Windows Features)\n- You run launcher as administrator.";

            if (lower.Contains("hax") && lower.Contains("not available"))
                return "HAXM is not available.\nMake sure Intel HAXM driver is installed and active.";

            if (lower.Contains("kvm") && lower.Contains("not available"))
                return "KVM is not available. You are probably not on Linux, or kvm module is not loaded.";

            if (lower.Contains("could not open") && lower.Contains("physicaldrive"))
                return "Could not open PhysicalDrive.\nDisk may be Online or in use by system. Try 'Set Offline' before starting.";

            if (lower.Contains("could not open") && (lower.Contains(".img") || lower.Contains(".qcow2")))
                return "Could not open disk image file.\nCheck if file exists and is accessible.";

            if (lower.Contains("accelerator") && lower.Contains("invalid"))
                return "Selected accelerator is not supported by your system. Try switching to TCG.";

            if (lower.Contains("access denied"))
                return "Access denied. Run launcher as administrator.";

            return $"QEMU reported an error:\n\n{errorText}";
        }

        private static bool IsValidMac(string mac) =>
            !string.IsNullOrWhiteSpace(mac) &&
            Regex.IsMatch(mac.Trim(), @"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$");

        // ----------------------------------------------------------------------
        // Event handlers
        // ----------------------------------------------------------------------
        private void BtnBrowseQemu_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "qemu-system-x86_64.exe|qemu-system-x86_64.exe|All files (*.*)|*.*";
                ofd.Title = "Select QEMU executable";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    txtQemuPath.Text = ofd.FileName;
                    ReloadQemuConfig();
                }
            }
        }

        private void BtnBrowseISO_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "ISO files (*.iso)|*.iso|All files (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                    txtISO.Text = ofd.FileName;
            }
        }

        private void CmbDiskType_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool isPhysical = cmbDiskType.SelectedItem?.ToString() == "PhysicalDrive";
            pnlPhysicalDrive.Visible = isPhysical;
            pnlHddImage.Visible = !isPhysical;
            if (isPhysical) RefreshPhysicalDrives();
        }

        private void BtnRefreshDrives_Click(object sender, EventArgs e) => RefreshPhysicalDrives();

        private void BtnSetOffline_Click(object sender, EventArgs e)
        {
            if (cmbPhysicalDrive.SelectedItem == null) return;
            string selected = cmbPhysicalDrive.SelectedItem.ToString();
            var match = Regex.Match(selected, @"Disk (\d+)");
            if (match.Success && int.TryParse(match.Groups[1].Value, out int diskNum))
            {
                if (SetDriveOffline(diskNum))
                {
                    MessageBox.Show($"Disk {diskNum} is now Offline. Refresh the list.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshPhysicalDrives();
                }
                else
                {
                    MessageBox.Show("Failed to set disk Offline. Run as Administrator and ensure the disk is not system.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnBrowseHDD_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Disk images (*.img;*.raw;*.qcow2;*.vhd;*.vmdk)|*.img;*.raw;*.qcow2;*.vhd;*.vmdk|All files (*.*)|*.*";
                if (ofd.ShowDialog() == DialogResult.OK)
                    txtHDD.Text = ofd.FileName;
            }
        }

        private void BtnCreateHDD_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "Raw image (*.img)|*.img|Qcow2 image (*.qcow2)|*.qcow2";
                if (sfd.ShowDialog() != DialogResult.OK) return;

                string path = sfd.FileName;
                string ext = Path.GetExtension(path).ToLowerInvariant();
                string format = ext == ".qcow2" ? "qcow2" : "raw";

                string size = ShowSizeDialog();
                if (string.IsNullOrEmpty(size)) return;

                string qemuDir = Path.GetDirectoryName(txtQemuPath.Text);
                string qemuImg = string.IsNullOrEmpty(qemuDir)
                    ? "qemu-img.exe"
                    : Path.Combine(qemuDir, "qemu-img.exe");

                if (!File.Exists(qemuImg))
                {
                    if (format != "raw")
                    {
                        MessageBox.Show("qemu-img.exe not found. Cannot create qcow2 image.", "Error");
                        return;
                    }
                    if (TryCreateRawImage(path, size))
                        txtHDD.Text = path;
                    return;
                }

                var psi = new ProcessStartInfo
                {
                    FileName = qemuImg,
                    Arguments = $"create -f {format} \"{path}\" {size}",
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true
                };

                using (var proc = Process.Start(psi))
                {
                    if (proc == null)
                    {
                        MessageBox.Show("Failed to start qemu-img.", "Error");
                        return;
                    }

                    // FIX: читаем stderr ДО WaitForExit, чтобы не получить deadlock
                    string errorOutput = proc.StandardError.ReadToEnd();

                    // FIX: проверяем, завершился ли процесс в разумное время
                    bool finished = proc.WaitForExit(30000);
                    if (!finished)
                    {
                        try { proc.Kill(); } catch (InvalidOperationException) { }
                        MessageBox.Show("qemu-img timed out.", "Error");
                        return;
                    }

                    if (proc.ExitCode == 0)
                        txtHDD.Text = path;
                    else
                        MessageBox.Show($"qemu-img create failed.\n{errorOutput}", "Error");
                }
            }
        }

        private string ShowSizeDialog()
        {
            using (Form sizeForm = new Form
            {
                Text = "Image Size",
                Size = new Size(300, 150),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false
            })
            {
                sizeForm.SuspendLayout();

                var label = new Label { Text = "Size (e.g. 10G, 512M):", Location = new Point(10, 20), Size = new Size(200, 20) };
                var textSize = new TextBox { Location = new Point(10, 50), Size = new Size(200, 20), Text = "10G" };
                var btnOk = new Button { Text = "OK", Location = new Point(100, 80), Size = new Size(75, 23), DialogResult = DialogResult.OK };

                sizeForm.Controls.AddRange(new Control[] { label, textSize, btnOk });
                sizeForm.AcceptButton = btnOk;

                sizeForm.ResumeLayout(false);
                sizeForm.PerformLayout();

                return sizeForm.ShowDialog() == DialogResult.OK ? textSize.Text.Trim() : null;
            }
        }

        private void BtnGenerateMAC_Click(object sender, EventArgs e)
        {
            var randomBytes = new byte[3];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(randomBytes);

            txtMAC.Text = $"52:54:00:{randomBytes[0]:X2}:{randomBytes[1]:X2}:{randomBytes[2]:X2}";
        }

        private bool TryCreateRawImage(string path, string size)
        {
            try
            {
                long sizeBytes = ParseSize(size);
                if (sizeBytes <= 0) return false;

                using (var fs = new FileStream(path, FileMode.CreateNew))
                    fs.SetLength(sizeBytes);

                return true;
            }
            catch { return false; }
        }

        private static long ParseSize(string size)
        {
            var match = Regex.Match(size.Trim(), @"^(\d+)([KMGkmg])?$");
            if (!match.Success) return 0;

            long num = long.Parse(match.Groups[1].Value);
            switch (match.Groups[2].Value.ToUpperInvariant())
            {
                case "K": return num * 1024L;
                case "M": return num * 1024L * 1024L;
                case "G": return num * 1024L * 1024L * 1024L;
                default: return num;
            }
        }

        // ----------------------------------------------------------------------
        // Physical drives
        // ----------------------------------------------------------------------
        private void RefreshPhysicalDrives()
        {
            _allDrives = GetPhysicalDrives();
            cmbPhysicalDrive.Items.Clear();

            if (_allDrives.Count == 0)
            {
                lblStatus.Text = "No physical drives detected or access denied.";
                return;
            }

            foreach (var drive in _allDrives)
                cmbPhysicalDrive.Items.Add($"Disk {drive.Number} ({drive.SizeGB} GB) - {drive.Status}");

            if (cmbPhysicalDrive.Items.Count > 0)
                cmbPhysicalDrive.SelectedIndex = 0;
        }

        private void RestorePhysicalDriveSelection()
        {
            if (string.IsNullOrEmpty(_pendingPhysicalDriveDisplay)) return;
            int idx = cmbPhysicalDrive.FindStringExact(_pendingPhysicalDriveDisplay);
            if (idx >= 0) cmbPhysicalDrive.SelectedIndex = idx;
        }

        // Получаем список дисков через WMI и обогащаем статусами из diskpart
        private List<PhysicalDriveInfo> GetPhysicalDrives()
        {
            var drives = new List<PhysicalDriveInfo>();

            try
            {
                // FIX: ManagementObjectCollection тоже нужно диспозировать
                using (var searcher = new ManagementObjectSearcher("SELECT Index, Size FROM Win32_DiskDrive"))
                using (var results = searcher.Get())
                {
                    foreach (ManagementBaseObject baseObj in results)
                    {
                        using (ManagementObject disk = (ManagementObject)baseObj)
                        {
                            int number = Convert.ToInt32(disk["Index"]);
                            ulong size = disk["Size"] != null ? (ulong)disk["Size"] : 0UL;
                            double sizeGB = Math.Round(size / 1073741824.0, 1);
                            drives.Add(new PhysicalDriveInfo(number, sizeGB, "Unknown"));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed to query physical drives: " + ex.Message;
                return drives;
            }

            // Обогащаем статусы через diskpart
            try
            {
                string diskpartOutput = RunDiskpartScript("list disk\nexit");
                if (!string.IsNullOrEmpty(diskpartOutput))
                    ApplyDiskpartStatuses(drives, diskpartOutput);
            }
            catch { /* не критично: статусы останутся "Unknown" */ }

            return drives;
        }

        private bool SetDriveOffline(int diskNumber)
        {
            try
            {
                string script = $"select disk {diskNumber}\r\noffline disk\r\nexit";
                string output = RunDiskpartScript(script);
                if (output == null) return false;

                string lower = output.ToLowerInvariant();
                bool hasError =
                    lower.Contains("error") ||
                    lower.Contains("ошибка") ||
                    lower.Contains("diskpart has encountered an error");

                return !hasError;
            }
            catch { return false; }
        }

        private bool GetDriveStatusOnline(int diskNumber)
        {
            try
            {
                string output = RunDiskpartScript("list disk\nexit");
                if (string.IsNullOrEmpty(output)) return false;

                foreach (string line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    var match = Regex.Match(line,
                        $@"(?:Disk|Диск)\s+{diskNumber}\s+(\S+)",
                        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

                    if (match.Success)
                    {
                        string status = NormalizeDiskStatus(match.Groups[1].Value.Trim());
                        return status.Equals("Online", StringComparison.OrdinalIgnoreCase);
                    }
                }
                return false;
            }
            catch { return false; }
        }

        // FIX: выделен единый метод запуска diskpart-скриптов, устраняет дублирование кода
        // и исправляет deadlock (ReadToEnd до WaitForExit)
        private static string RunDiskpartScript(string scriptContent)
        {
            string tempFile = null;
            try
            {
                tempFile = Path.GetTempFileName();
                File.WriteAllText(tempFile, scriptContent, Encoding.UTF8);

                var psi = new ProcessStartInfo("diskpart", $"/s \"{tempFile}\"")
                {
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    // Кодировка 866 для русской Windows-консоли
                    StandardOutputEncoding = Encoding.GetEncoding(866),
                    StandardErrorEncoding = Encoding.GetEncoding(866),
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (var proc = Process.Start(psi))
                {
                    if (proc == null) return null;

                    // FIX: читаем оба потока асинхронно через Task, чтобы избежать deadlock
                    var stdoutTask = proc.StandardOutput.ReadToEndAsync();
                    var stderrTask = proc.StandardError.ReadToEndAsync();

                    bool finished = proc.WaitForExit(DiskpartTimeoutMs);
                    if (!finished)
                    {
                        try { proc.Kill(); } catch (InvalidOperationException) { }
                        return null;
                    }

                    // Дожидаемся завершения чтения потоков
                    Task.WaitAll(stdoutTask, stderrTask);
                    return stdoutTask.Result + stderrTask.Result;
                }
            }
            finally
            {
                if (tempFile != null)
                    try { File.Delete(tempFile); } catch { }
            }
        }

        // Применяет статусы из вывода diskpart "list disk" к списку дисков
        private static void ApplyDiskpartStatuses(List<PhysicalDriveInfo> drives, string diskpartOutput)
        {
            foreach (string line in diskpartOutput.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
            {
                var match = Regex.Match(line,
                    @"(?:Disk|Диск)\s+(\d+)\s+(\S+)",
                    RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

                if (!match.Success) continue;

                if (!int.TryParse(match.Groups[1].Value, out int diskNum)) continue;

                string status = NormalizeDiskStatus(match.Groups[2].Value.Trim());
                var drive = drives.Find(d => d.Number == diskNum);
                if (drive != null) drive.Status = status;
            }
        }

        private static string NormalizeDiskStatus(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return "Unknown";
            string s = raw.Trim().ToLowerInvariant();

            if (s == "online" || s == "on-line" || s == "ok" ||
                s == "в сети" || s == "онлайн" || s == "он-лайн")
                return "Online";

            if (s == "offline" || s == "off-line" ||
                s == "офлайн" || s == "не в сети" || s == "оф-лайн")
                return "Offline";

            return char.ToUpperInvariant(raw[0]) + raw.Substring(1);
        }

        // ----------------------------------------------------------------------
        // Command confirmation dialog
        // ----------------------------------------------------------------------
        private static DialogResult ShowCommandDialog(IWin32Window owner, string fullCommand)
        {
            using (Form dialog = new Form
            {
                Text = "QEMU command line",
                Size = new Size(900, 400),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false
            })
            {
                dialog.SuspendLayout();

                var consolasFont = new Font("Consolas", 9);
                TextBox txtCommand = new TextBox
                {
                    Multiline = true,
                    ReadOnly = true,
                    ScrollBars = ScrollBars.Both,
                    Dock = DockStyle.Fill,
                    Font = consolasFont,
                    Text = fullCommand,
                    WordWrap = false
                };

                Button btnCopy = new Button { Text = "Copy to Clipboard", Width = 130, Height = 30 };
                Button btnRun = new Button { Text = "Run", Width = 80, Height = 30, DialogResult = DialogResult.OK };
                Button btnCancel = new Button { Text = "Cancel", Width = 80, Height = 30, DialogResult = DialogResult.Cancel };

                btnCopy.Click += (s, ev) =>
                {
                    try
                    {
                        Clipboard.SetText(fullCommand);
                        MessageBox.Show("Command copied to clipboard.", "Copied", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Copy failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                };

                var panel = new FlowLayoutPanel
                {
                    FlowDirection = FlowDirection.RightToLeft,
                    Dock = DockStyle.Bottom,
                    Height = 40,
                    Padding = new Padding(5)
                };
                panel.Controls.AddRange(new Control[] { btnCancel, btnRun, btnCopy });

                dialog.Controls.Add(panel);
                dialog.Controls.Add(txtCommand);
                dialog.AcceptButton = btnRun;
                dialog.CancelButton = btnCancel;

                dialog.ResumeLayout(false);
                dialog.PerformLayout();

                return dialog.ShowDialog(owner);
            }
        }

        // ----------------------------------------------------------------------
        // Start QEMU
        // ----------------------------------------------------------------------
        private async void BtnStart_Click(object sender, EventArgs e)
        {
            string qemuPath = txtQemuPath.Text.Trim();
            if (!File.Exists(qemuPath))
            {
                MessageBox.Show($"QEMU not found at:\n{qemuPath}\nPlease select correct path.", "Error");
                return;
            }

            string accelType = cmbAccelerator.SelectedItem?.ToString() ?? "TCG";
            bool accelNeedsAdmin =
                accelType.IndexOf("Hyper-V", StringComparison.OrdinalIgnoreCase) >= 0 ||
                accelType.IndexOf("HAXM", StringComparison.OrdinalIgnoreCase) >= 0;

            bool isAdmin = IsRunAsAdmin();

            if (accelNeedsAdmin && !isAdmin)
            {
                DialogResult res = MessageBox.Show(
                    $"Accelerator '{accelType}' requires administrator rights.\nRestart launcher as administrator?",
                    "Insufficient rights", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                if (res == DialogResult.Yes) { RestartAsAdmin(); return; }
                if (res == DialogResult.Cancel) return;

                // No: сброс на TCG
                cmbAccelerator.SelectedIndex = 0;
                accelType = "TCG (software)";
                accelNeedsAdmin = false;
            }

            string ramText = cmbRAM.Text.Trim();
            if (!int.TryParse(ramText, out int memMb) || memMb <= 0)
            {
                memMb = 1024;
                cmbRAM.Text = memMb.ToString();
            }

            string cpuModel = cmbCPU.SelectedItem?.ToString() ?? "qemu64";
            string cores = cmbCores.SelectedItem?.ToString() ?? "2";
            string machine = cmbChipset.SelectedItem?.ToString() ?? "pc";
            string videoCard = cmbVideo.SelectedItem?.ToString() ?? "std";
            string networkModel = cmbNetworkModel.SelectedItem?.ToString() ?? "e1000";
            string keyboardType = cmbKeyboard.SelectedItem?.ToString() ?? "PS/2";
            string mouseType = cmbMouse.SelectedItem?.ToString() ?? "USB Tablet";
            string diskType = cmbDiskType.SelectedItem?.ToString() ?? "HDD Image";

            if (memMb > 4096)
                machine += ",phys-bits=36";

            if (!IsValidMac(txtMAC.Text))
            {
                MessageBox.Show("Invalid MAC address format. Expected: XX:XX:XX:XX:XX:XX", "Error");
                return;
            }

            // Акселератор
            string accel;
            switch (cmbAccelerator.SelectedIndex)
            {
                case 1: accel = "whpx"; break;
                case 2: accel = "hax"; break;
                case 3: accel = "kvm"; break;
                default: accel = "tcg"; break;
            }

            var args = new List<string>
            {
                $"-machine {machine}",
                $"-cpu {cpuModel}",
                $"-smp {cores}",
                $"-m {memMb}",
                accel == "whpx"
                    ? $"-accel {accel},kernel-irqchip=off"
                    : $"-accel {accel}"
            };

            // --- Физический диск ---
            if (diskType == "PhysicalDrive")
            {
                if (!isAdmin)
                {
                    DialogResult res = MessageBox.Show(
                        "PhysicalDrive access requires administrator rights.\nRestart launcher as administrator?",
                        "Insufficient rights", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                    if (res == DialogResult.Yes) { RestartAsAdmin(); return; }
                    if (res == DialogResult.Cancel) return;
                    // No: продолжаем на свой страх и риск
                }

                string selected = cmbPhysicalDrive.SelectedItem?.ToString();
                if (string.IsNullOrEmpty(selected))
                {
                    MessageBox.Show("No physical drive selected.", "Error");
                    return;
                }

                var matchDisk = Regex.Match(selected, @"Disk\s+(\d+)");
                if (!matchDisk.Success || !int.TryParse(matchDisk.Groups[1].Value, out int diskNum))
                {
                    MessageBox.Show("Failed to parse disk number.", "Error");
                    return;
                }

                if (GetDriveStatusOnline(diskNum))
                {
                    var res = MessageBox.Show(
                        $"Drive Disk {diskNum} is ONLINE. It must be Offline. Set Offline now?",
                        "Warning", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);

                    if (res == DialogResult.Yes)
                    {
                        if (!SetDriveOffline(diskNum))
                        {
                            MessageBox.Show("Failed to set disk offline.", "Error");
                            return;
                        }
                        RefreshPhysicalDrives();
                    }
                    else if (res == DialogResult.Cancel)
                        return;
                    // No: продолжаем
                }

                args.Add($"-drive file=\\\\.\\PhysicalDrive{diskNum},format=raw,if=ide,index=0,media=disk");
            }
            else
            {
                // --- Образ диска ---
                if (!string.IsNullOrWhiteSpace(txtHDD.Text) && File.Exists(txtHDD.Text))
                {
                    string format = Path.GetExtension(txtHDD.Text).ToLowerInvariant() == ".qcow2" ? "qcow2" : "raw";
                    string controller = cmbHddController.SelectedItem?.ToString() ?? "IDE";

                    switch (controller)
                    {
                        case "AHCI":
                            args.Add("-device ahci,id=ahci");
                            args.Add($"-drive file=\"{txtHDD.Text}\",format={format},if=none,id=drive0");
                            args.Add("-device ide-hd,drive=drive0,bus=ahci.0");
                            break;
                        case "SCSI":
                            args.Add("-device lsi53c895a,id=scsi");
                            args.Add($"-drive file=\"{txtHDD.Text}\",format={format},if=none,id=drive0");
                            args.Add("-device scsi-hd,drive=drive0,bus=scsi.0");
                            break;
                        default: // IDE
                            args.Add($"-drive file=\"{txtHDD.Text}\",format={format},if=ide,index=0,media=disk");
                            break;
                    }
                }
                else
                {
                    var res = MessageBox.Show(
                        "HDD image not selected or not found. Continue without a disk?",
                        "Continue without disk", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    if (res == DialogResult.No) return;
                }
            }

            // --- ISO ---
            bool hasIso = !string.IsNullOrWhiteSpace(txtISO.Text) && File.Exists(txtISO.Text);
            if (hasIso)
                args.Add($"-drive file=\"{txtISO.Text}\",format=raw,if=ide,index=1,media=cdrom");

            // FIX: исправлена логика boot order.
            // Оригинал: case 0 и case 2 оба давали "d", case 1 и case 3 — "c",
            // но "Only CD-ROM" и "Only HDD" требуют флага once= и отсутствия второго носителя.
            string bootOrder;
            string bootFlag;
            switch (cmbBootOrder.SelectedIndex)
            {
                case 1: // HDD first
                    bootOrder = "c";
                    bootFlag = $"-boot order={bootOrder}";
                    break;
                case 2: // Only CD-ROM
                    bootOrder = "d";
                    bootFlag = "-boot once=d,menu=on";
                    break;
                case 3: // Only HDD
                    bootOrder = "c";
                    bootFlag = "-boot once=c,menu=on";
                    break;
                case 4: // Network (PXE) first
                    bootOrder = "n";
                    bootFlag = $"-boot order={bootOrder}";
                    break;
                default: // case 0: CD-ROM first
                    bootOrder = "d";
                    bootFlag = $"-boot order={bootOrder}";
                    break;
            }
            args.Add(bootFlag);

            // --- USB / Клавиатура / Мышь ---
            bool needUsbController =
                keyboardType == "USB" ||
                mouseType == "USB Mouse" ||
                mouseType == "USB Tablet";

            if (needUsbController)
            {
                string usbControllerChoice = cmbUsbController.SelectedItem?.ToString() ?? "Auto";
                string usbDevice;

                if (usbControllerChoice == "Auto")
                {
                    usbDevice = machine.IndexOf("q35", StringComparison.OrdinalIgnoreCase) >= 0
                        ? "qemu-xhci"
                        : "piix3-usb-uhci";
                }
                else if (usbControllerChoice.StartsWith("XHCI", StringComparison.OrdinalIgnoreCase))
                    usbDevice = "qemu-xhci";
                else if (usbControllerChoice.StartsWith("EHCI", StringComparison.OrdinalIgnoreCase))
                    usbDevice = "usb-ehci";
                else
                    usbDevice = "piix3-usb-uhci";

                args.Add($"-device {usbDevice},id=usb");
            }

            if (keyboardType == "PS/2" || mouseType == "PS/2")
                args.Add("-device i8042");

            if (keyboardType == "USB")
                args.Add("-device usb-kbd" + (needUsbController ? ",bus=usb.0" : ""));

            switch (mouseType)
            {
                case "USB Mouse":
                    args.Add("-device usb-mouse" + (needUsbController ? ",bus=usb.0" : ""));
                    break;
                case "USB Tablet":
                    args.Add("-device usb-tablet" + (needUsbController ? ",bus=usb.0" : ""));
                    break;
            }

            // --- Видео ---
            args.Add($"-vga {videoCard}");

            // --- Аудио ---
            if (chkAudio.Checked && cmbAudioBackend.SelectedItem != null)
            {
                string backend = cmbAudioBackend.SelectedItem.ToString();
                args.Add($"-audiodev {backend},id=audio0");
                args.Add("-device AC97,audiodev=audio0");
            }

            // --- Сеть ---
            string networkType = cmbNetwork.SelectedItem?.ToString() ?? "None";
            if (networkType == "User (Slirp)")
            {
                args.Add("-netdev user,id=net0");
                args.Add($"-device {networkModel},netdev=net0,mac={txtMAC.Text.Trim()}");
            }
            else if (networkType == "Tap (Bridge)")
            {
                args.Add("-netdev tap,id=net0,ifname=tap0,script=no,downscript=no");
                args.Add($"-device {networkModel},netdev=net0,mac={txtMAC.Text.Trim()}");
            }

            // --- Размер окна ---
            if (numWidth.Value > 0 && numHeight.Value > 0)
            {
                if (ResizableVgaCards.Contains(videoCard))
                {
                    args.Add($"-global VGA.width={(int)numWidth.Value}");
                    args.Add($"-global VGA.height={(int)numHeight.Value}");
                }
                else
                {
                    lblStatus.Text = "Window size ignored: not supported for this video card.";
                }
            }

            // --- Дополнительные аргументы ---
            if (!string.IsNullOrWhiteSpace(txtExtraArgs.Text))
                args.Add(txtExtraArgs.Text.Trim());

            // --- Предупреждение: нет ISO, но загрузка с CD ---
            if (!hasIso && bootOrder == "d")
            {
                var res = MessageBox.Show(
                    "No ISO selected. Continue booting from HDD?",
                    "Boot device missing", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (res == DialogResult.Yes)
                {
                    // Заменяем boot-флаг
                    args.RemoveAll(a => a.StartsWith("-boot "));
                    args.Add("-boot order=c");
                    bootOrder = "c";
                }
                else
                {
                    return;
                }
            }

            string arguments = string.Join(" ", args);
            string fullCommand = $"\"{qemuPath}\" {arguments}";

            if (ShowCommandDialog(this, fullCommand) != DialogResult.OK)
                return;

            bool canRedirect = isAdmin || !(accelNeedsAdmin || diskType == "PhysicalDrive");

            ProcessStartInfo psi;
            if (canRedirect)
            {
                psi = new ProcessStartInfo
                {
                    FileName = qemuPath,
                    Arguments = arguments,
                    UseShellExecute = false,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    WorkingDirectory = Path.GetDirectoryName(qemuPath) ?? string.Empty
                };
            }
            else
            {
                psi = new ProcessStartInfo
                {
                    FileName = qemuPath,
                    Arguments = arguments,
                    UseShellExecute = true,
                    Verb = "runas"
                };
            }

            try
            {
                var proc = Process.Start(psi);
                if (proc == null)
                {
                    MessageBox.Show("Process could not be started. Possibly cancelled by user.",
                        "Launch aborted", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var token = _cancellationTokenSource.Token;
                await Task.Run(() =>
                {
                    try
                    {
                        // FIX: читаем stderr асинхронно относительно WaitForExit, чтобы не было deadlock.
                        // Task.Run уже выполняется в пуле потоков, поэтому блокирующий WaitForExit здесь безопасен,
                        // но stderr читаем параллельно через отдельный Task.
                        string errorOutput = null;

                        Task<string> stderrTask = psi.RedirectStandardError
                            ? proc.StandardError.ReadToEndAsync()
                            : Task.FromResult<string>(null);

                        bool exitedQuickly = proc.WaitForExit(3000);

                        if (!exitedQuickly || !IsHandleCreated || IsDisposed || token.IsCancellationRequested)
                            return;

                        // Дожидаемся stderr
                        stderrTask.Wait();
                        errorOutput = stderrTask.Result;

                        string message = !string.IsNullOrWhiteSpace(errorOutput)
                            ? AnalyzeQemuError(errorOutput)
                            : "QEMU process exited quickly (within 3 seconds).\n\n" +
                              "Common causes:\n" +
                              "• Invalid command-line parameters\n" +
                              "• Missing administrator rights (required for WHPX/HAXM/PhysicalDrive)\n" +
                              "• Selected accelerator is not available\n" +
                              "• Disk image is missing or locked by another process";

                        Invoke((MethodInvoker)(() =>
                        {
                            if (!IsDisposed)
                                MessageBox.Show(this, message, "QEMU launch error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }));
                    }
                    catch (OperationCanceledException) { }
                    catch { /* процесс мог завершиться раньше, чем мы успели прочитать */ }
                }, token);
            }
            catch (OperationCanceledException)
            {
                // Форма закрывается — игнорируем
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to start QEMU: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ----------------------------------------------------------------------
        // Settings
        // ----------------------------------------------------------------------
        private void BtnSave_Click(object sender, EventArgs e)
        {
            var settings = new AppSettings
            {
                QemuPath = txtQemuPath.Text,
                ISO = txtISO.Text,
                DiskType = cmbDiskType.SelectedItem?.ToString() ?? "HDD Image",
                PhysicalDriveDisplay = cmbPhysicalDrive.SelectedItem?.ToString() ?? "",
                HDDImage = txtHDD.Text,
                CPU = cmbCPU.SelectedItem?.ToString() ?? "qemu64",
                Cores = cmbCores.SelectedItem?.ToString() ?? "2",
                RAM = cmbRAM.Text,
                Chipset = cmbChipset.SelectedItem?.ToString() ?? "pc",
                Audio = chkAudio.Checked,
                Video = cmbVideo.SelectedItem?.ToString() ?? "std",
                Network = cmbNetwork.SelectedItem?.ToString() ?? "None",
                NetworkModel = cmbNetworkModel.SelectedItem?.ToString() ?? "e1000",
                MAC = txtMAC.Text,
                WindowWidth = numWidth.Value,
                WindowHeight = numHeight.Value,
                AudioBackend = cmbAudioBackend.SelectedItem?.ToString() ?? "dsound",
                AcceleratorIndex = cmbAccelerator.SelectedIndex,
                ExtraArgs = txtExtraArgs.Text,
                BootOrderIndex = cmbBootOrder.SelectedIndex,
                HddControllerIndex = cmbHddController.SelectedIndex,
                KeyboardType = cmbKeyboard.SelectedItem?.ToString() ?? "PS/2",
                MouseType = cmbMouse.SelectedItem?.ToString() ?? "USB Tablet",
                UsbController = cmbUsbController.SelectedItem?.ToString() ?? "Auto"
            };

            string json = JsonConvert.SerializeObject(settings, Formatting.Indented);
            File.WriteAllText(SettingsFilePath, json, Encoding.UTF8);
            lblStatus.Text = "Settings saved.";
        }

        private void BtnLoad_Click(object sender, EventArgs e)
        {
            LoadSettingsFromFile();
            // RefreshPhysicalDrives вызывается внутри CmbDiskType_SelectedIndexChanged,
            // если выбран PhysicalDrive. Вызываем явно только для восстановления выбора.
            RefreshPhysicalDrives();
            RestorePhysicalDriveSelection();
            CmbDiskType_SelectedIndexChanged(null, EventArgs.Empty);
        }

        private void LoadSettingsFromFile()
        {
            if (!File.Exists(SettingsFilePath)) return;

            AppSettings settings;
            try
            {
                string json = File.ReadAllText(SettingsFilePath, Encoding.UTF8);
                settings = JsonConvert.DeserializeObject<AppSettings>(json);
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Failed to load settings: " + ex.Message;
                return;
            }

            if (settings == null) return;

            txtQemuPath.Text = settings.QemuPath;
            txtISO.Text = settings.ISO;

            SelectComboByValue(cmbDiskType, settings.DiskType);

            // Pending-значения применятся после ReloadQemuConfig, когда комбобоксы будут заполнены
            _pendingCpu = settings.CPU;
            _pendingChipset = settings.Chipset;
            _pendingVideo = settings.Video;
            _pendingAudioBackend = settings.AudioBackend;
            _pendingNetworkModel = settings.NetworkModel;
            _pendingPhysicalDriveDisplay = settings.PhysicalDriveDisplay;

            txtHDD.Text = settings.HDDImage;
            SelectComboByValue(cmbCores, settings.Cores);
            cmbRAM.Text = settings.RAM;
            chkAudio.Checked = settings.Audio;
            cmbAudioBackend.Enabled = chkAudio.Checked;
            txtMAC.Text = settings.MAC;
            SafeSetNumericValue(numWidth, settings.WindowWidth);
            SafeSetNumericValue(numHeight, settings.WindowHeight);
            txtExtraArgs.Text = settings.ExtraArgs;

            if (settings.AcceleratorIndex >= 0 && settings.AcceleratorIndex < cmbAccelerator.Items.Count)
                cmbAccelerator.SelectedIndex = settings.AcceleratorIndex;

            if (settings.BootOrderIndex >= 0 && settings.BootOrderIndex < cmbBootOrder.Items.Count)
                cmbBootOrder.SelectedIndex = settings.BootOrderIndex;

            if (settings.HddControllerIndex >= 0 && settings.HddControllerIndex < cmbHddController.Items.Count)
                cmbHddController.SelectedIndex = settings.HddControllerIndex;

            SelectComboByValue(cmbNetwork, settings.Network);
            SelectComboByValue(cmbKeyboard, settings.KeyboardType);
            SelectComboByValue(cmbMouse, settings.MouseType);
            SelectComboByValue(cmbUsbController, settings.UsbController);

            lblStatus.Text = "Settings loaded.";
        }

        private void LoadSettingsOnStart()
        {
            if (File.Exists(SettingsFilePath))
                LoadSettingsFromFile();
            else
                txtQemuPath.Text = DefaultQemuPath;

            ReloadQemuConfig();

            // FIX: CmbDiskType_SelectedIndexChanged уже вызовет RefreshPhysicalDrives(),
            // если выбран PhysicalDrive. Двойного вызова здесь больше нет.
            CmbDiskType_SelectedIndexChanged(null, EventArgs.Empty);
            RestorePhysicalDriveSelection();
        }

        private static void SafeSetNumericValue(NumericUpDown control, decimal value)
        {
            control.Value = Math.Max(control.Minimum, Math.Min(control.Maximum, value));
        }
    }
}
